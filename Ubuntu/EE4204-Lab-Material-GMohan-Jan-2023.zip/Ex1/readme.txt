This example is to show how to transmit a short packet using TCP and UDP.
Input a string (less than 50 characters) at the client end, you will receive the string at the server.