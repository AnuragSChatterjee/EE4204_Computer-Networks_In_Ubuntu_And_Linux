/*******************************
udp_client.c: the source file of the client in udp
********************************/

#include "headsock.h"

void str_cli1(FILE *fp, int sockfd, struct sockaddr *addr, int addrlen, long *len);   //transmission function    
void tv_sub(struct  timeval *out, struct timeval *in);	    //calcu the time interval between out and in         

int main(int argc, char *argv[])
{
	long len;
	int sockfd, ret;
	struct sockaddr_in ser_addr;
	char **pptr;
	struct hostent *sh;
	struct in_addr **addrs;
	float ti, rt;
	FILE *fp; 

	if (argc!= 2)
	{
		printf("parameters not match.");
		exit(0);
	}

	if ((sh=gethostbyname(argv[1]))==NULL) {             //get host's information
		printf("error when gethostbyname");
		exit(0);
	}

	sockfd = socket(AF_INET, SOCK_DGRAM, 0);             //create UDP socket
	if (sockfd<0)
	{
		printf("error in socket");
		exit(1);
	}
 
	addrs = (struct in_addr **)sh->h_addr_list;
	printf("canonical name: %s\n", sh->h_name);

	for (pptr=sh->h_aliases; *pptr != NULL; pptr++)
		printf("the aliases name is: %s\n", *pptr);			//printf socket information

	switch(sh->h_addrtype)
	{
		case AF_INET:
			printf("AF_INET\n");
		break;
		default:
			printf("unknown addrtype\n");
		break;
	}

	sockfd = socket(AF_INET, SOCK_STREAM, 0);                           //create the socket
	if (sockfd <0)
	{
		printf("error in socket");
		exit(1);
	}

	ser_addr.sin_family = AF_INET;
	ser_addr.sin_port = htons(MYUDP_PORT);  //Connects to UDP Port 5350 in 'headsock.h'
	memcpy(&(ser_addr.sin_addr.s_addr), *addrs, sizeof(struct in_addr));
	bzero(&(ser_addr.sin_zero), 8);

	ret = connect(sockfd, (struct sockaddr *)&ser_addr, sizeof(struct sockaddr));         //connect the socket with the host
	if (ret != 0) {
		printf ("connection failed\n"); 
		close(sockfd); 
		exit(1);
	}
	
	if((fp = fopen ("myfile.txt","r+t")) == NULL)
	{
		printf("File doesn't exit\n");
		exit(0);
	}

// 	str_cli1(stdin, sockfd, (struct sockaddr *)&ser_addr, sizeof(struct sockaddr_in), &len);   // receive and send

// 	close(sockfd);
// 	exit(0);
// }

	ti = str_cli(fp, sockfd, &len);                       //perform the transmission and receiving
	if (ti != -1)	{
		rt = (len/(float)ti);                                         //caculate the average transmission rate
		printf("Ave Time(ms) : %.3f, Ave Data sent(byte): %d\nAve Data rate: %f (Kbytes/s)\n", ti, (int)len, rt);
	}
	// rt = (len/(float)ti);                                 //caculate the average transmission rate
	// printf("Time(ms) : %.3f, Data sent(byte): %d\nData rate: %f (Kbytes/s)\n", ti, (int)len, rt);

	close(sockfd); 
	fclose(fp);
//}
	exit(0);
}

float str_cli(FILE *fp, int sockfd, long *len)
{
	char *buf;
	long lsize, ci;
	struct pack_so sends;
	struct ack_so acks;
	char sends[DATALEN];
	// struct ack_so ack;
	int n, slen;
	float time_inv = 0.0;
	struct timeval sendt, recvt;
	ci = 0;

	fseek (fp , 0 , SEEK_END);
	*len = lsize = ftell (fp);
	rewind (fp);
	printf("The file length is %d bytes\n", (int)lsize);
	printf("the packet length is %d bytes\n",DATALEN);

// allocate memory to contain the whole file.
	buf = (char *) malloc (lsize);
	if (buf == NULL) exit (2);

  // copy the file into the buffer.
	
	//fread (buf,1,lsize,fp);

  // copy the file into the buffer.
	fread (sends.data,1,lsize,fp);					//read the file data into the data area in packet


  /*** the whole file is loaded in the buffer. ***/
	buf[lsize] ='\0';									//append the end byte
	gettimeofday(&sendt, NULL);							//get the current time
	sends.len = lsize;									//the data length
	sends.num = 0;

	
	n=send(sockfd, &sends, (sends.len+HEADLEN), 0);		//send the data in one packet
	if (n == -1)	{			
		printf("error sending data\n");
		exit(1);
	}
	else printf("%d data sent", n);
	if ((n=recv(sockfd, &acks, 2, 0)) == -1) {	        //receive ACK or NACK
		printf("error receiving data\n");
		exit(1);
	}
	if ((acks.len == 0) && (acks.num == 1))         //if it is ACK
	{
		gettimeofday(&recvt, NULL);                                                         //get current time
		tv_sub(&recvt, &sendt);                                                                 // get the whole trans time
		time_inv += (recvt.tv_sec)*1000.0 + (recvt.tv_usec)/1000.0;
		return(time_inv);
	}
	else	{
		return(-1);
		printf("Error in transmission\n");
	}
}



/////////////////////////////////////////////////////


// 	while(ci<= lsize) 
// 	{
// 		if ((lsize+1-ci) <= DATALEN)
// 			slen = lsize+1-ci;
// 		else 
// 			slen = DATALEN;
// 		memcpy(sends, (buf+ci), slen);
// 		n = send(sockfd, &sends, slen, 0);

// 		sendto(sockfd, &sends, strlen(sends), 0, addr, addrlen);                         //send the packet to server
// 		printf("send out!!\n");

// 		if(n == -1) {
// 			printf("send error!");								//send the data
// 			exit(1);
// 		}
// 		ci += slen;
// 	}
// 	if ((n= recv(sockfd, &ack, 2, 0))==-1)                                   //receive the ack
// 	{
// 		printf("error when receiving\n");
// 		exit(1);
// 	}
// 	if (ack.num != 1|| ack.len != 0)
// 		printf("error in transmission\n");
// 	gettimeofday(&recvt, NULL);
// 	*len= ci;                                                         //get current time
// 	tv_sub(&recvt, &sendt);                                                                 // get the whole trans time
// 	time_inv += (recvt.tv_sec)*1000.0 + (recvt.tv_usec)/1000.0;
// 	return(time_inv);
// }



////////////////////////////////////////////////////////////////
void tv_sub(struct  timeval *out, struct timeval *in)
{
	if ((out->tv_usec -= in->tv_usec) <0)
	{
		--out ->tv_sec;
		out ->tv_usec += 1000000;
	} 
	out->tv_sec -= in->tv_sec;
}
// void str_cli1(FILE *fp, int sockfd, struct sockaddr *addr, int addrlen, int *len)
// {
// 	char sends[MAXSIZE];

// 	printf("Please input a string (less than 50 characters):\n");
// 	if (fgets(sends, MAXSIZE, fp) == NULL) {
// 		printf("error input\n");
// 	}


// }

  



